from django.contrib import admin
from django.urls import path,include
from . import views
from django.conf import settings
from django.conf.urls.static import static





urlpatterns = [
    ##############################  all page ##############################
    path('registration/', views.registration, name="registration"),
    path('login/', views.login, name="login"),
    path('coupon/', views.coupon, name="coupon"),
    path('customer/', views.customer, name="customer"),
    
    # path('monthly_sales/', views.monthly_sales, name="monthly_sales"),x
    
    path('logoutpage/', views.logoutpage, name="logoutpage"),
    
    # path('loginuser/', views.loginuser, name="login"),
    
    path('userupadte/<int:id>', views.userupadte, name="userupadte"),
    
    # path('Usercart/', views.usercart, name="Usercart"),
    # path('index/', views.index, name="index"),

    path('brand/', views.brand, name="brand"),
    path('order/', views.order, name="order"),
    path('P_review/', views.P_review, name="P_review"),
    
    
    path('productstocks/', views.productstocks, name="productstocks"),
    path('loginpage/', views.loginpage, name="loginpage"),
    path('', views.dashboardpage, name="dashboardpage"),
    path('basepage/', views.basepage, name="basepage"),
    path('footerpage/', views.footerpage, name="footerpage"),
    path('sidebarpage/', views.sidebarpage, name="sidebarpage"),
    path('headerpage/', views.headerpage, name="headerpage"),
    path('category/', views.category, name="category"),
    path('product/', views.product, name="product"),
    path('usercart/', views.usercart, name="usercart"),
    
    


    # path('upload/', views.upload, name="upload"),
    
    
    path('price/', views.price, name="price"),
    path('price2/', views.price2, name="price2"),
  
    ##############################  Category ##############################

    path('categoryDelete/<int:id>', views.categoryDelete, name="categoryDelete"),
    path('categoryInsert/', views.categoryInsert, name="categoryInsert"),
    path('categoryUpdate/<int:id>', views.categoryUpdate, name="categoryUpdate"),
    
    
    ##############################  Product ##############################
    
    path('productInsert/', views.productInsert, name="productInsert"),
    path('productDelete/<int:id>', views.productDelete, name="productDelete"),
    path('productUpdate/<int:id>', views.productUpdate, name="productUpdate"),
    
    
     ##############################  Product Stocks ##############################
     
    path('stocksInsert/', views.stocksInsert, name="stocksInsert"),
    path('stockDelete/<int:id>', views.stockDelete, name="stockDelete"),
    path('ProductUpdate/<int:id>', views.ProductUpdate, name="ProductUpdate"),
    
    
     ##############################  Brand  ############################## 
     
    path('brandInsert/', views.brandInsert, name="brandInsert"),
    path('brandUpdate/<int:id>', views.brandUpdate, name="brandUpdate"),
    path('brandDelete/<int:id>', views.brandDelete, name="brandDelete"),
    
     ##############################  Order  ############################## 
    
    path('orderInsert/', views.orderInsert, name="orderInsert"),
    path('OrderDelete/<int:id>', views.OrderDelete, name="OrderDelete"),
    path('OrderUpdate/<int:id>', views.OrderUpdate, name="OrderUpdate"),
   
     ##############################  PASSWORD  ############################## 
     
    path('change-password/<token>/', views.ChangePassword, name="ChangePassword"),
    
    path('forgetpassword/', views.ForgetPassword, name="ForgetPassword"),
    
##############################  couponCart  ############################## 
path('cartInsert/', views.cartInsert, name="cartInsert"),
path('cartDelete/<int:id>', views.cartDelete, name="cartDelete"),
path('cartUpdate/<int:id>', views.cartUpdate, name="cartUpdate"),

############################# Products-Review #############################
# path('P_review/', views.P_review,name = 'P_review'),
path('Insertreview/', views.Insertreview, name="Insertreview"),
path('update_review/<int:id>', views.update_review, name="update_review"),
path('Delte_Review/<int:id>', views.Delte_Review, name="Delte_Review"),

#############################User cart#######################################
path('UserInsert/', views.UserInsert, name="UserInsert"),
path('UserDelete/<int:id>', views.UserDelete, name="UserDelete"),

path('UserCartUpdate/<int:id>', views.UserCartUpdate, name="UserCartUpdate"),



########################## Meetings ##########################################
path('meetings', views.showUserMeeting, name="meetings"),
path('meetingupdate', views.meeting_update, name="meetingupdate"),
path('delmeeting/<int:id>', views.deleteUserMeeting, name="delmeeting"),
##################################### user wishlist urls ######################

path('wishlist', views.showWishList, name="wishlist"),

#################################### Toggle ######################################
 path('changeStatusoffercard/<int:id>', views.change_state_brand, name="changeStatusoffercard"),
 path('changeStatusoffer/<int:id>', views.change_state_offer, name="changeStatusoffer"),

 path('changeStatusProduct/<int:id>', views.change_state_product, name="changeStatusProduct"),
 
 path('changeStatusCat/<int:id>', views.change_state_Category, name="changeStatusCat"),
#  path('changeStatususer/<int:id>', views.change_state_user, name="changeStatususer"),
 
 
path('customerDelete/<int:id>', views.customerDelete, name="customerDelete"),
 

###################################### user forgot paaswprd  ############################################################
    path('send_mail', views.send_mails, name="send_mail"),
    path('setpwd', views.set_pwd, name="setpwd"),

    
    
  
  
  
  
  
  


]
urlpatterns = urlpatterns + static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)


