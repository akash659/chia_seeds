from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
import uuid



################################ Category ##################################################
class Category(models.Model):
    categoryName=models.CharField(max_length=100, default="")
    categoryIcon=models.ImageField(upload_to="api_app/img", default="")
    status=models.CharField( max_length=20, blank=True)
    createDate=models.DateTimeField(default=timezone.now)
    updateDate=models.DateTimeField(auto_now=True)
    def __str__(self):
        return f"{self.categoryName}"

################################## Product ################################################### 
class Product(models.Model):
    userid=models.ForeignKey(to=User,on_delete=models.CASCADE)
    categoryid=models.ForeignKey(to=Category,on_delete=models.CASCADE)
    productname=models.CharField(max_length=200, default="")
    productdescription=models.CharField(max_length=300, default="")
    productimages=models.ImageField(upload_to="api_app/img", blank=True)
    productThumbnail=models.ImageField(upload_to="api_app/img", blank=True)
    productprice=models.IntegerField(blank=True)

    productdiscountPercentage=models.IntegerField(blank=True)
    productdiscountPrice=models.IntegerField(blank=True)
    productfinalPrice=models.IntegerField(blank=True,null=True)
    gsttax = models.IntegerField(blank=True)

    productqty=models.IntegerField(blank=True)
    productmetaTitle=models.CharField(max_length=200, default="")
    status=models.CharField(max_length=20, default="True")
    createdate=models.DateTimeField(default=timezone.now)
    updatedate=models.DateTimeField(auto_now=True)
    def __str__(self):
        return f"{self.productname}"

class Image(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    images = models.ImageField(upload_to="api_app/img")
    
    def __str__(self):
        return self.product.productname
   
################################## Product stock ################################################### 

class ProductStock(models.Model):
    productId=models.ForeignKey(to=Product,on_delete=models.CASCADE)
    Variant=models.CharField(max_length=200, default="")
    purchaseQty=models.IntegerField()
    soldQty=models.IntegerField()
    stockQty=models.IntegerField()
    unitPrice=models.IntegerField()
    salePrice=models.IntegerField()
    Price=models.IntegerField()
    serialNumber=models.IntegerField()
    createDate=models.DateTimeField(default=timezone.now)
    updateDate=models.DateTimeField(auto_now=True)
    def __str__(self):
        return f"{self.Variant}"

    
################################## Brand ################################################### 
    
class Brandd(models.Model):
    brandName=models.CharField(max_length=100,default="")
    brandLogo=models.ImageField(upload_to="api_app/img")
    status=models.CharField( max_length=20, blank=True)
    createDate=models.DateTimeField(default=timezone.now)
    updateDate=models.DateTimeField(auto_now=True)
 
################################## order ################################################### 
   
class Order(models.Model):
    ProductStockId=models.ForeignKey(to=ProductStock,on_delete=models.CASCADE)
    ProductId=models.ForeignKey(to=Product,on_delete=models.CASCADE)
    orderId = models.CharField(max_length=200, default="")
    orderQty=models.IntegerField()
    tranctionNumber = models.IntegerField()
    deliveryCharge = models.IntegerField()
    orderstatus= models.CharField(max_length=50, default="")
    paymentMethod = models.CharField(max_length=200, default="")
    tranctionId = models.CharField(max_length=200, default="")
    shipingInfo= models.CharField(max_length=300, default="")
    billingInfo= models.CharField(max_length=300, default="")
    paymentstatus=models.CharField(max_length=50, default="")
    orderComment=models.CharField(max_length=500, default="")
    totalAmount=models.IntegerField(max_length=10)
    createDate=models.DateTimeField(default=timezone.now)
    updateDate=models.DateTimeField(auto_now=True)
################################ forgot password #################################################################

class Profile(models.Model):
    user= models.OneToOneField(User, on_delete=models.CASCADE)   
    forget_password_token=models.CharField(max_length=1000)
    created_at= models.DateTimeField(auto_now_add=True)
    
############################### Coupon card #####################################################################

    
class couponcard(models.Model):
    userid=models.ForeignKey(to=User,on_delete=models.CASCADE)
    productname=models.ForeignKey(to=Product,on_delete=models.CASCADE)
    from_date=models.DateField(default=timezone.now)
    to_date=models.DateField(default=timezone.now)
    discount=models.IntegerField(blank=True)
    card_id=models.CharField(max_length=8,unique=True,editable=False)                            
    
    status=models.CharField(max_length=20, default="True")
    createDate=models.DateTimeField(default=timezone.now)
    updateDate=models.DateTimeField(auto_now=True)
    
############################################### Customer ###############################################################
# class Userss(models.Model):
#     username = models.ForeignKey(to=User,on_delete=models.CASCADE)
#     is_superuser=models.CharField(max_length=5)
#     customerEmail = models.EmailField(max_length=100,blank=None)
#     date_joined = models.DateField(default=timezone.now)
#     Status=models.CharField( max_length=20, blank=True)

    # UpdateDate = models.DateTimeField(auto_now=True)
    
########################################### User activity ##############################################################

class UserActivity(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    time = models.DateField(default=timezone.now)
    details = models.CharField(max_length=255)

########################### PRODUCT REVIEW ######################################

class ProductReview(models.Model):
    userid=models.ForeignKey(to=User,on_delete=models.CASCADE)
    product_name=models.ForeignKey(to=Product,on_delete=models.CASCADE)
    reviewDescription=models.CharField(max_length=500, default="")
    reviewTitle=models.CharField(max_length=200, default="")
    reviewRating=models.IntegerField()
    reviewImage=models.ImageField(upload_to="api_app/img", default="")
    createDate=models.DateTimeField(default=timezone.now)
    updateDate=models.DateTimeField(default=timezone.now)
    
#################################### User-Cart #######################################

class UserCart(models.Model):
    userID=models.ForeignKey(to=User,on_delete=models.CASCADE)
    product=models.ForeignKey(to=Product,on_delete=models.CASCADE)
    orderQty=models.IntegerField()
    createDate=models.DateTimeField(default=timezone.now)
    updateDate=models.DateTimeField(default=timezone.now)

########################################## UserMeeting ##############################################################

class UserMeeting(models.Model):
    userName=models.ForeignKey(to=User,on_delete=models.CASCADE)
    userMail=models.CharField(max_length=100, default="")
    meetTitle=models.CharField(max_length=200, default="")
    meetDescription=models.CharField(max_length=5000, default="")
    meetTime=models.DateTimeField(default=timezone.now)
    meetLink=models.CharField(max_length=500, default="",blank=True)
    status=models.CharField(default="False", max_length=20, blank=True)
    createDate=models.DateTimeField(default=timezone.now)
    updateDate=models.DateTimeField(default=timezone.now)
    
##################################### WishList ###################################################################################

class WishList(models.Model):
    user=models.ForeignKey(to=User,on_delete=models.CASCADE)
    productData=models.ForeignKey(to=Product,on_delete=models.CASCADE)
    createDate=models.DateTimeField(default=timezone.now)
    updateDate=models.DateTimeField(default=timezone.now)