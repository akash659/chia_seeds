from django.forms import ModelForm
from django import forms

from .models import Image
# from django.contrib.auth.forms import UserCreationForm
# from .models import Client, Admin

# class ClientCreationForm(UserCreationForm):
#     class Meta:
#         model = Client
#         fields = ('email', 'first_name', 'last_name')

# class AdminCreationForm(UserCreationForm):
#     class Meta:
#         model = Admin
#         fields = ('email', 'first_name', 'last_name')

class ImageForm(ModelForm):
    images = forms.ImageField(widget=forms.FileInput(attrs={"class":"form-control", "multiple":True}))
    class Meta:
        model = Image
        fields = ['images']