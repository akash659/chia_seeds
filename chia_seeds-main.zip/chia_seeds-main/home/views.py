import math
from django.shortcuts import render
from django.shortcuts import render,redirect, HttpResponse,get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .models import*
from django.contrib import messages 
from django.contrib.auth.models import User,auth
from .helpers import send_forget_password_mail
import uuid
import string
import json
from django.db.models import Sum
import random
from datetime import datetime, timedelta
import calendar
from django.db.models.functions import TruncMonth
from django.db.models import Count
from django.http import JsonResponse
from django.core.mail import send_mail
meeing_head="Your meeting Details"



############################################### login & Logout ########################################

def registration(request):
    if request.method == "POST":
        first_name= request.POST['first']
        last_name= request.POST['last']
        email= request.POST['email']
        password= request.POST['password']
        confirm_password= request.POST['paasword1']
        username= request.POST['username']
        
        if password == confirm_password:
            
            if User.objects.filter(username=username,email=email).exists():
                messages.info(request,"email is already exist")
                return redirect(registration)
            else:
                user= User.objects.create_user(username=username,password=password,email=email,first_name=first_name,last_name=last_name)
                user.set_password(password)
                user.save()
                return redirect("/login")
    else: 
        return render(request,"adminTemplate/registration.html")


def login(request):
    if request.method == "POST":
        username= request.POST['username']
        password= request.POST['password']
        # user_type= request.POST['user_type']
        user= auth.authenticate(username=username,password=password)
        if user is not None:
            auth.login(request, user)
            if user.is_superuser:
                messages.success(request,"Successfully authenticated as Admin")
                return redirect("dashboardpage")
            else:
                messages.success(request,"Successfully authenticated as User")
                return redirect("price")
        else:
            messages.info(request,"Invalid Username or Password")
            return redirect("login")
    else:
        return render(request,"adminTemplate/login_user.html")
    
def logoutpage(request):
    logout(request)
    return redirect("login")
    
    
############################## all page #################################

def customer(request):
    Userss=User.objects.all()
    # result6= Userss.objects.all()
    return render(request,'adminTemplate/users.html',{'Userss':Userss})

def coupon(request):
    Products= Product.objects.all()
    users= User.objects.all()
    cart= couponcard.objects.all()
    return render(request,"adminTemplate/couponcart.html",{'Products':Products,'users':users,'cart':cart})

@login_required(login_url='login')
def order(request):
    Orders=Order.objects.all()
    print(Orders,'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa')
    users= ProductStock.objects.all()
    Products=Product.objects.all()
    return render(request,"adminTemplate/order.html",{"users":users,"Products":Products,"Orders":Orders})
    
@login_required(login_url='login')
def brand(request):
    data= Brandd.objects.all()
    return render(request,"adminTemplate/brand.html",{'data':data})

@login_required(login_url='login')
def category(request):
    result= Category.objects.all()
    return render(request,'adminTemplate/Category.html',{'result':result})

@login_required(login_url='login')
def productstocks(request):
    stocks=ProductStock.objects.all()
    stocks1=Product.objects.all()
    return render(request,'adminTemplate/stock.html',{'stocks':stocks,'stocks1':stocks1})

@login_required(login_url='login')
def product(request):
    img=[]
    results1= Product.objects.all()
    # results= Product.objects.all()
    users = User.objects.all()
    category=Category.objects.all()
    images=Image.objects.all()
    for k in range(0,len(results1)):
        counter=0
        for i in range(0,len(images)):
            if(results1[k].pk==images[i].product.pk):
                img.append({"count":counter,"product":{"id":images[i].product.pk},"images":images[i].images})
                counter=counter+1
    print(img,'kkkkkkkkkkkkkkk')
    # print(category,'gggggggggggggg')
    return render(request,'adminTemplate/product.html',{'results1':results1,'users':users,'category':category,'images':images,'img':img})

@login_required(login_url='login')
def dashboardpage(request):
    prodd= Product.objects.all()
    # for i in prodd:
    #     akaaa= list(i.values())[0:2][0]
    #     prodstatus= list(i.values())[0:2][1]
        
        
 
    # print(akaaa,prodstatus,'88888888888888888888888888888888888888888888888888888')
    # Userss=User.objects.()
    orders=Order.objects.all().count()
    prod= Product.objects.all().count()
    orderss=Order.objects.all()
    results1= Product.objects.all()
    threshold_date = datetime.now() - timedelta(days=7)
    users= User.objects.filter(date_joined__gte=threshold_date)
    Orders= Order.objects.filter(createDate__gte=threshold_date)
    cat= Category.objects.all().count()
    total_amount = Order.objects.aggregate(total_amount=Sum('totalAmount'))['total_amount']                 
    user= User.objects.all().count()
    today = datetime.now().date()
    start_of_month = today.replace(day=1)
    end_of_last_month = start_of_month - timedelta(days=1)
    start_of_last_month = end_of_last_month.replace(day=1)
    last_month_income = Order.objects.filter(createDate__range=(start_of_last_month, end_of_last_month)).aggregate(Sum('totalAmount'))
    x=last_month_income['totalAmount__sum']
    
    cat1= Category.objects.all()
    offer= couponcard.objects.all().count()
    prodstock= ProductStock.objects.all().count()
    activity = UserActivity(user=request.user, details="New user Joined")
    activities = UserActivity.objects.order_by('time')

    monthly_revenues = Order.objects.values('createDate__year', 'createDate__month').annotate(total_revenue=Sum('totalAmount'))
    for revenue in monthly_revenues:
        month_number = revenue['createDate__month']
        revenue['month_name'] = calendar.month_name[month_number]
    
    monthly_sales = Order.objects.annotate(month=TruncMonth('createDate')).values('month').annotate(total_sales=Count('id')).values('month', 'total_sales')   
   
    
    
    monthly_revenues = Order.objects.values('createDate__month').annotate(total_revenue=Sum('totalAmount'))
    print(monthly_revenues,"@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
    for revenue in monthly_revenues:
        month_number = revenue['createDate__month']
        revenue['month_name'] = calendar.month_name[month_number]
    
    
    rons=[]
    ronss=[]
    ronak=[]
    for i in monthly_revenues:
        aka= list(i.keys())[0]
        ron= list(i.values())[1:3][0]
        ronak= list(i.values())[1:3][1]
        
        
        # a=aka
        b=ron
        c=ronak
        ronss.append(c)
        rons.append(b)
        # print(rons,'888888888888888888888888888888888888888888')
    
    monthly_stock=ProductStock.objects.values('createDate__month').annotate(stock_price=Sum('Price'))    
    for stockk in monthly_stock:
        month_number = stockk['createDate__month']
        stockk['month_name'] = calendar.month_name[month_number]
        
        
    akash=[]
    ronaks=[]
    for i in monthly_stock:
        # akk= list(i.keys())[0]
        s=list(i.values())[1:3][0]
        akaa= list(i.values())[1:3][1]
        # myDict={akaa}
        
        
        
        d=s
        k=akaa
        akash.append(d)
        ronaks.append(k)
        # print(akash,'111111111111111111111111111111111111111111')
        print(akaa,'222222222222222222222222222222222222222')
    return render(request,'adminTemplate/dashboard.html',{'prodd':prodd,'results1':results1,'orders':orders,'prod':prod,'users':users,'Orders':Orders,'cat':cat,'total_amount':total_amount,'last_month_income':x,'cat1':cat1,'offer':offer,'prodstock':prodstock,'user':user,'activity':activity,'activities':activities,'orderss':orderss,'monthly_revenues': monthly_revenues,'monthly_sales':monthly_sales,'rons':rons,'ronss':ronss,'ronak':ronak,'akash':akash,'ronaks':ronaks})


def basepage(request):
    return render(request,'adminTemplate/base.html')


def footerpage(request):
    return render(request,'adminTemplate/footer.html')

def P_review(request):
    results=ProductReview.objects.all()
    prod= Product.objects.all()
    users=User.objects.all()
    print(prod,'ggggggggggggggggggggg')
    return render(request,'adminTemplate/product-review.html',{'results':results,'prod':prod,'users':users})

def sidebarpage(request):
    return render(request,'adminTemplate/sidebar.html')


def headerpage(request):
    Userss=User.objects.all()
    return render(request,'adminTemplate/header.html',{'Userss':Userss})


def loginpage(request):
    return render(request,'login.html')

def usercart(request):
   result5= UserCart.objects.all()
   users=User.objects.all()
   prod=Product.objects.all()
   return render(request,'adminTemplate/usercaart.html',{'result5':result5,'users':users,'prod':prod})

def price(request):
    return render(request,'adminTemplate/price.html')


def price2(request):
    return render(request,'adminTemplate/price2.html')



##############################  Category ##############################
def categoryInsert(request):
    if request.method =='POST':
        category=request.FILES['File']
        categoryImage= request.POST['Cname']
        form= Category( categoryIcon=category,categoryName=categoryImage)
        form.save()
        messages.success(request, 'Image Added Successfully')
        return redirect('/category')


def categoryDelete(request,id):
    member = Category.objects.get(id=id)
    member.delete()
    return redirect('/category')


def categoryUpdate(request,id):
   y= Category.objects.get(id=id)
   if request.method=='POST':
        try:
            y.categoryIcon = request.FILES['File']
        except:
            pass
        y.categoryName= request.POST['Cname']
        y.save()
        messages.success(request, 'Image Updated Successfully')
        
        return redirect("/category")
   return render(request,'adminTemplate/category.html')



##############################  Product ##############################
def productInsert(request):
    if request.method == 'POST':
        try:
            user=request.POST['userId']
            userobj=User.objects.get(id=user)   
            Categoryid=request.POST['categoryId']
            catobj=Category.objects.get(id=Categoryid)
        except:
            pass
        ProductName=request.POST['productName']
        ProductDescription=request.POST['productDescription']
        ProductTitle=request.POST['productTitle']
        ProductQty=request.POST['Productqty']
        Thumbnail= request.FILES['myFile']
        Price=request.POST['price']
        Gst=request.POST['gst']
        Discount=request.POST['discount']
        DiscountPrice=request.POST['discount-price']
        Finalprice=request.POST['final-price']
        Pimage=request.FILES.getlist('images')
        
        
        
        form=Product(userid=userobj,categoryid=catobj,productThumbnail=Thumbnail,productname=ProductName,productdescription=ProductDescription,
                     productprice=Price,productdiscountPercentage=Discount,productdiscountPrice=float(DiscountPrice),
                     productfinalPrice=float(Finalprice),gsttax=Gst,productqty=ProductQty,productmetaTitle=ProductTitle)
        
    
        
        form.save()
        print(Pimage,'ooooooooooooo')
        obj=Product.objects.get(productname=ProductName)
        # obj_img=Image()
        for i in Pimage:
            Image.objects.create(product=obj,images=i)
          
        messages.success(request, 'Image Added Successfully')
        return redirect('/product')




def productUpdate(request,id):
    print('hello')
    i= Product.objects.get(id=id)
    if request.method == 'POST':
        try:
            i.productThumbnail=request.FILES['myFile']
        except:
            pass

        categoryid=request.POST['categoryId']
        catobj=Category.objects.get(id=categoryid)
        user=request.POST['userId']
        userobj=User.objects.get(id=user)
        i.productname=request.POST['productName']
        i.productdescription=request.POST['productDescription']
        i.productprice=request.POST['price']
        i.productdiscountPercentage=request.POST['discount']
        i.productdiscountPrice=request.POST['discount-price']
        i.gsttax=request.POST['gst']
        i.productfinalPrice=request.POST['final-price']
        i.productqty=request.POST['Productqty']
        i.productmetaTitle=request.POST['productTitle']
        i.userid=userobj
        i.categoryid=catobj
        i.save()
        obj=Image.objects.all()
        try:
            img=request.FILES.getlist('images')
            print(len(img))
            if(len(img)!=0):
                for k in obj:
                    if(k.product.pk==id):
                        obj_del=Image.objects.get(id=k.pk)
                        obj_del.delete()
                for j in img:
                    Image.objects.create(product=i,images=j)
            else:
                for i in obj:
                    if(i.product.pk==id):
                        try:
                            img=request.FILES[f'images-{i.pk}']
                            obj_img=Image.objects.get(id=i.pk)
                            obj_img.images=img
                            obj_img.save()
                        except Exception as e:
                            print(e,'llllllllllllllll')
        except Exception as e:
            print(e,'jjjjjjjjjjjj')
            

            

        messages.success(request, 'Image Updated Successfully')
    
        return redirect("/product")
    return redirect("/product")

    return render(request,'adminTemplate/product.html')


def productDelete(request,id):
    i=Product.objects.get(id=id)
    i.delete()
    return redirect('/product')


##############################  Product Stocks##############################

def stocksInsert(request):
    if request.method == 'POST':
            product= request.POST["Pid"]
            prodobj=Product.objects.get(id=product)
            variant= request.POST["variant"]
            purcahse= request.POST["PurchaseQty"]
            sold= request.POST["SoldQty"]
            stock= request.POST["StockQty"]
            unit= request.POST["UPrice"]
            sale= request.POST["SalePrice"]
            price= request.POST["price"]
            
            serialnumber= request.POST["SerialNumber"]
            
            form= ProductStock(productId=prodobj,Variant=variant,purchaseQty=purcahse,soldQty=sold,stockQty=stock,unitPrice=unit,salePrice=sale,
                               Price=price,serialNumber=serialnumber)
            
            form.save()
            return redirect("/productstocks")
        
def ProductUpdate(request,id):
    i= ProductStock.objects.get(id=id)
    if request.method == "POST":
            product= request.POST["Pid"]
            prodobj= Product.objects.get(id=product)
            i.Variant= request.POST["variant"]
            i.purchaseQty= request.POST["PurchaseQty"]
            i.soldQty= request.POST["SoldQty"]
            i.stockQty= request.POST["StockQty"]
            i.unitPrice= request.POST["UPrice"]
            i.salePrice= request.POST["SalePrice"]
            i.Price= request.POST["price"]
            i.serialNumber= request.POST["SerialNumber"]
            i.productId=prodobj
            i.save()
            return redirect("/productstocks")
    
        
def stockDelete(request,id):
    i=ProductStock.objects.get(id=id)
    i.delete()
    return redirect('/productstocks')   

##############################  Brand  ##############################

def brandInsert(request):
    if request.method == "POST":
        brand= request.POST["brand"]
        logo= request.FILES["File"]
        
        form= Brandd(brandName=brand,brandLogo=logo)
        form.save()
        return redirect("/brand")
    
def brandUpdate(request,id):
    a= Brandd.objects.get(id=id)
    if request.method == "POST":
        a.brandName= request.POST["brand"]
        a.brandLogo= request.FILES["File"]
        a.save()
        return redirect("/brand")
    
def brandDelete(request,id):
    a=Brandd.objects.get(id=id)
    a.delete()
    return redirect("/brand")    

 ##############################  order  ##############################
 
def OrderDelete(request,id):
    i= Order.objects.get(id=id)
    i.delete()
    return redirect("/order")


def orderInsert(request):
 if request.method == 'POST':
        try:
            user=request.POST['user']
            userobj=ProductStock.objects.get(id=user)   
            productid=request.POST['product']
            prodobj=Product.objects.get(id=productid)
        except:
            pass
        orderQuantity=request.POST['orderQty']
        orderid=request.POST['orderId']
        transaction=request.POST['tranctionNumber']
        transactionid= request.POST['tranctionId']
        delivery=request.POST['deliveryCharge']
        Ostatus=request.POST['orderstatus']
        payment=request.POST['paymentMethod']
        shiping=request.POST['shipingInfo']
        billing=request.POST['billingInfo']
        payment_status=request.POST['paymentstatus']
        comment=request.POST['orderComment']
        amount=request.POST['amount']
        
    
        
        form=Order(ProductStockId=userobj,ProductId=prodobj,orderId= orderid,orderQty= orderQuantity,tranctionNumber=transaction,
                   deliveryCharge=delivery,orderstatus=Ostatus,paymentMethod=payment,tranctionId=transactionid,shipingInfo=shiping,
                   billingInfo=billing,paymentstatus=payment_status, orderComment=comment,totalAmount=amount)
        
        
        
        form.save()
        
        messages.success(request, 'Image Added Successfully')
        return redirect('/order')


def OrderUpdate(request,id):
    data= Order.objects.get(id=id)
    if request.method ==  "POST":
              
        productid=request.POST['product']
        prodobj=Product.objects.get(id=productid)
        user=request.POST['user']
        userobj=ProductStock.objects.get(id=user)
        
        data.orderId=request.POST['orderId']
        data.orderQty=request.POST['orderQty']
        data.deliveryCharge=request.POST['deliveryCharge']
        data.tranctionNumber=request.POST['tranctionNumber']
        data.orderstatus=request.POST['orderstatus']
        data.paymentMethod=request.POST['paymentMethod']
        data.tranctionId=request.POST['tranctionId']
        data.shipingInfo=request.POST['shipingInfo']
        data.billingInfo=request.POST['billingInfo']
        data.paymentstatus=request.POST['paymentstatus']
        data.orderComment=request.POST['orderComment']
        data.totalAmount=request.POST['amount']
        data.ProductStockId=userobj
        data.ProductId=prodobj
        data.save()
        return redirect("/order")
####################################################### Forget PASSWORD  #########################################################

def ChangePassword(request , token):
    context = {}
    
    
    try:
        profile_obj = Profile.objects.filter(forget_password_token = token).first()
        context = {'user_id' : profile_obj.user.id}
        
        if request.method == 'POST':
            new_password = request.POST.get('new_password')
            confirm_password = request.POST.get('reconfirm_password')
            user_id = request.POST.get('user_id')
            
            if user_id is  None:
                messages.success(request, 'No user id found.')
                return redirect(f'/change-password/{token}/')
                
            
            if  new_password != confirm_password:
                messages.success(request, 'both should  be equal.')
                return redirect(f'/change-password/{token}/')
                         
            
            user_obj = User.objects.get(id = user_id)
            user_obj.set_password(new_password)
            user_obj.save()
            return redirect('/login/')
  
    except Exception as e:
        print(e)
    return render(request , 'change-password.html' , context)



def ForgetPassword(request):
    try:
        if request.method == 'POST':
            username = request.POST.get('username')
            
            if not User.objects.filter(username=username).first():
                messages.success(request, 'Not user found with this username.')
                print('inside if ')
                return redirect('/forgetpassword/')
            else:
            
                user_obj = User.objects.get(username = username)
                token = str(uuid.uuid4())
                profile_obj= Profile.objects.get(user = user_obj)
                profile_obj.forget_password_token = token
                profile_obj.save()
                send_forget_password_mail(user_obj.email , token)
                messages.success(request, 'An email is sent.')
                print(token,'aaaaaaaaaaaaaaaaaaaa')
                return redirect('/forgetpassword/')
                
    
    
    except Exception as e:
        print(e)
    return render(request , 'adminTemplate/forget-password.html')
########################################## coupon cart #############################################################

def cartInsert(request):    
    if request.method == 'POST':
        letters = string.ascii_uppercase + string.digits
        coupon_code = ''.join(random.choice(letters) for i in range(8))
        user=request.POST['user']
        userobj=User.objects.get(id=user) 
        pro= request.POST['product']
        proobj= Product.objects.get(id=pro)
        fromdate=request.POST['f_date']
        todate=request.POST['to_date'] 
        discount=request.POST['discount']
       
        form= couponcard(userid=userobj,productname=proobj,from_date=fromdate,to_date=todate,discount=discount,card_id=coupon_code)
                    
        form.save()
        messages.success(request, 'Image Added Successfully')
        return redirect('/coupon')
    
def cartDelete(request,id):
    data= couponcard.objects.get(id=id)
    data.delete()
    return redirect("/coupon")

def cartUpdate(request,id):
    data= couponcard.objects.get(id=id)
    if request.method ==  "POST":
              
        user=request.POST['user']
        userobj=User.objects.get(id=user) 
        pro= request.POST['product']
        proobj= Product.objects.get(id=pro)
        
        
        data.from_date=request.POST['f_date']
        data.to_date=request.POST['to_date']
        data.discount=request.POST['discount']
        data.userid=userobj
        data.productname=proobj
        data.save()
        return redirect("/coupon") 

##################################### Product-Review ####################################################


# def product_review(request): 
#     results = ProductReview.objects.all() 
#     users = User.objects.all()
#     return render(request,'adminTemplate/product-review.html' , {'results': results, 'users':users})

def Insertreview(request):
    if request.method == 'POST':
        x = request.POST['user']
        userobj = User.objects.get(id = x)
        product_name =  request.POST['Pname']
        prodobj= Product.objects.get(id=product_name)
        R_description = request.POST['reviewDescription']
        R_rating= request.POST['reviewRating']
        R_title= request.POST['reviewTitle']
        # U_id= request.POST['user']  
        
        R_image = request.FILES['reviewimage']
      
    

        obj = ProductReview()
        obj.userid =userobj

        obj.product_name = prodobj
        obj.reviewDescription = R_description
        obj.reviewRating = R_rating
        obj.reviewTitle = R_title
        obj.reviewImage = R_image
       
        obj.save()
        return redirect('/P_review')
       # print(Offercard,'000000000')
    else:
        return render(request,'adminTemplate/product-review.html' )

def update_review(request,id): 
    i= ProductReview.objects.get(id=id)
    if request.method=='POST':
        try:
            i.reviewImage= request.FILES['myFiless']
        except:
            pass
       
        user= request.POST['userId']
        userobj= User.objects.get(id=user)
        product= request.POST['Pname']
        prodobj= Product.objects.get(id=product)
       
       
        i.reviewDescription= request.POST['R_description']
        i.reviewTitle=request.POST['R_title']
        i.reviewRating=request.POST['R_rating']
        i.userid= userobj
        i.product_name=prodobj
    
        i.save()
    return redirect('/P_review')
    # return render(request,'adminTemplate/product-review.html')
    
        
    


def Delte_Review(request,id):
    i=ProductReview.objects.get(id=id)
    i.delete()
    return redirect('/P_review')

############################################## User-Cart ############################################################
def UserInsert(request):
    if request.method== 'POST':
        user= request.POST['user']
        userobj= User.objects.get(id=user)
        prod= request.POST['prodd']
        prodobj=Product.objects.get(id=prod)
        orderqt= request.POST['orderqty']
        
        form= UserCart(userID=userobj,product=prodobj,orderQty=orderqt)
        form.save()
        return redirect('/usercart')

def UserDelete(request,id):
    k=UserCart.objects.get(id=id)
    k.delete()
    return redirect('/usercart')

def UserCartUpdate(request,id):
    k= UserCart.objects.get(id=id)
    if request.method== 'POST':
     
        user= request.POST['user']
        pproduct= request.POST['prodd']
        userobj=User.objects.get(id=user)
        prodobj= Product.objects.get(id=pproduct)
        k.userID=userobj
        k.product=prodobj
        k.orderQty= request.POST['orderqty']
        k.save()
        return redirect('/usercart')
 
########################################### Meeting ######################################################
def showUserMeeting(request):    
    try:

        showUserMeeting = UserMeeting.objects.all()
        return render(request,'adminTemplate/user_meeting.html',{'showUserMeeting':showUserMeeting, 'meeting_active':'active'})
    except Exception as e:
        print(e,'aaaaaaaaaaaaaaaaa')
        return render(request,'404.html')
    


def meeting_update(request):
    if request.method=="POST":
        id=request.POST['meet_id']
        obj=UserMeeting.objects.get(id=id)
        meet_link=request.POST['meet_link']
        meet_time=request.POST['meet_time']

        obj.meetLink=meet_link
        obj.meetTime=meet_time
        obj.status="True"
        obj.save()
        obj=UserMeeting.objects.get(id=id)
        
        msg=f'Your meeting time is {str(obj.meetTime)} \n \n Your meeting link is {obj.meetLink}'
        send_mail(meeing_head,msg,'akshv112000@gmail.com',[obj.userMail])

        return redirect('meetings')
    else:
        return render(request,' 404.html')
    

def deleteUserMeeting(request, id):
    meetingObj = UserMeeting.objects.get(pk=id)
    meetingObj.delete()
    return redirect('meetings')

############################################### user wishlist #####################################################################################################################


def showWishList(request):    
    try:
        showWishList = WishList.objects.all()
        print(showWishList,'aaaaaaaaaaaaa')
        return render(request,'adminTemplate/user_wishlist.html',{'showWishList':showWishList,'wishlist_active':'active'})
    except Exception as e:
        print(e,'ssssssssssss')
        return render(request,'404.html') 

######################################## Toggle button #################################################

def  change_state_brand(request, id):
    try:
        get_data = Brandd.objects.get(pk=id)
        if get_data.status == "True":
            get_data.status="False"
        else:
            get_data.status="True"

        get_data.save()
        return redirect('brand')
    except Exception as e:
        print(e)
        return render(request,'404.html')   
    
def  change_state_Category(request, id):
    try:
        get_data = Category.objects.get(pk=id)
        if get_data.status == "True":
            get_data.status="False"
        else:
            get_data.status="True"

        get_data.save()
        return redirect('category')
    except Exception as e:
        print(e)
        return render(request,'404.html')
    
def  change_state_product(request, id):
    try:
        get_data = Product.objects.get(pk=id)
        if get_data.status == "True":
            get_data.status="False"
        else:
            get_data.status="True"

        get_data.save()
        return redirect('product')
    except Exception as e:
        print(e)
        return render(request,'404.html')
    
def  change_state_offer(request, id):
    try:
        get_data = couponcard.objects.get(pk=id)
        if get_data.status == "True":
            get_data.status="False"
        else:
            get_data.status="True"

        get_data.save()
        return redirect('coupon')
    except Exception as e:
        print(e)
        return render(request,'404.html')
    
# def  change_state_user(request, id):
#     try:
#         get_data = Userss.objects.get(pk=id)
#         if get_data.Status == "True":
#             get_data.Status="False"
#         else:
#             get_data.Status="True"

#         get_data.save()
#         return redirect('customer')
#     except Exception as e:
#         print(e)
#         return render(request,'adminTemplate/users.html')
########################################### Consumer ###############################################################
def customerDelete(request,id):
  V= User.objects.get(id=id)  
  V.delete()
  return redirect('/customer')

def userupadte(request,id):
    user= User.objects.get(id=id)
    if request.method == 'POST':
        user.username= request.POST['username']
        user.first_name = request.POST['fname']
        user.last_name = request.POST['lname']
        user.email = request.POST['email']
        #  user.last_login = request.POST['login']
        user.save()
        return redirect('')



########################################## forgot password functions ##############################################
def generateOTP() :
     digits = "0123456789"
     OTP = ""
     for i in range(4) :
         OTP += digits[math.floor(random.random() * 10)]
     return OTP

def send_mails(request):

    global otp
    if request.method=="POST":
        try:  
           a=request.POST['id']
        except:
            a=''
        if a!='':
            otps=request.POST['otp']
            id=request.POST['id']

            if(otp==otps):
                return render(request,'adminTemplate/login_user.html',{"id":id,"state":"set_pwd"})
            else:

                    
                return render(request,'adminTemplate/login_user.html' ,{"state":"otp","msg":"Otp is not correct"})
        else:
            
            email=request.POST['email']
            
            try:
                user=User.objects.get(email=email)
            except Exception as e:
                print(e,'aaaaaaaaaaaaaaaaaaaaaaaaaas')
                user=[]
                
            if(user!=[]):
                otp=generateOTP()
                # htmlgen = '<p>Your OTP is <strong>o</strong></p>'
                send_mail('OTP request',f'{otp}','princejagani277@gmail.com',[email])


                return render(request,'adminTemplate/login_user.html' ,{"id":user.id ,"state":"otp"})
            else:
                messages.info(request,"email is not exist")
                return render(request,'adminTemplate/login_user.html')
        # return HttpResponse(email)
    else:

        return render(request,'adminTemplate/login_user.html')
    

def set_pwd(request):
    if request.method=="POST":
        pwd=request.POST['pwd']
        con_pwd=request.POST['con_pwd']
        id=request.POST['id']
        if(pwd==con_pwd):
            user=User.objects.get(id=id)
            user.set_password(pwd)
            user.save()
            return redirect('login')
    else:
        print('ggggggggggg')
        

def check_otp(request):
    if request.method=="POST":
        otps=request.POST['otp']
        id=request.POST['id']

        if(otp==otps):
            return render(request,'adminTemplate/login_user.html',{"id":id,"state":"set_pwd"})
        else:
            return HttpResponse('error')
     
    
    



