from django.contrib import admin
from .models import* 

admin.site.register(Category)
admin.site.register(Image)
admin.site.register(Product)
admin.site.register(ProductStock)
admin.site.register(Brandd)
admin.site.register(Order)
admin.site.register(Profile)
admin.site.register(couponcard)
# admin.site.register(Userss)
admin.site.register(UserActivity)
admin.site.register(UserCart)
admin.site.register(ProductReview)
admin.site.register(UserMeeting)
admin.site.register(WishList)
# admin.site.register(Customer)
















# Register your models here.
